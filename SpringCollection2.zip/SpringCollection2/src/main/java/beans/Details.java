package beans;

public class Details {
    String name;
    String college;
    String course;
	public Details(String name,String college, String course) {
		super();
		System.out.println("Details parameterized constructor");
		this.name=name;
		this.course = course;
		this.college = college;
	     System.out.println("*****************************************************");
	}
	public String getName() {
		return name;
	}
	public String getCollege() {
		return college;
	}
	public String getCourse() {
		return course;
	}
	
	
	
	
}
