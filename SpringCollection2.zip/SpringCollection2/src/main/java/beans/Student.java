package beans;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("student")
public class Student{
	private Map<String,Details> map;
	@Autowired(required=true)
	Student(Map<String,Details> map){
		  System.out.println("Student parameterized constructor");
		  System.out.println("*****************************************************");
	      this.map=map;
	}
	public void display() {
		 //firstWay();
		for(Entry entry :map.entrySet()){
			 System.out.println("Key=> "+entry.getKey());
			 System.out.println("Name: "+((Details) entry.getValue()).getName());
			 System.out.println("College: "+((Details) entry.getValue()).getCollege());
			 System.out.println("Course: "+((Details) entry.getValue()).getCourse());
			  System.out.println("*****************************************************");
		}
	}
	private void firstWay() {
		Set<Entry<String, Details>> entry=map.entrySet();
		 Iterator itr=entry.iterator();
		 while(itr.hasNext()){
			 Map.Entry m1=(Map.Entry)itr.next();
			System.out.println("Key: "+m1.getKey()+" Value: "+m1.getValue()); 
		 }
		
	}


}
