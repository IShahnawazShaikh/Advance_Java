package Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import beans.Details;
@Configuration
@ComponentScan("beans")
public class Config {
	@Bean("Object[1]")
	public Details getInstance1(){
		return new Details("shahnawaz","HMR-ITM","Computer Science Engineering");
	}
	@Bean("Object[2]")
	public Details getInstance2(){
		return new Details("Arif","MAIT","Computer Science Engineering");
	}
	@Bean("Object[3]")
	public Details getInstance3(){
		return new Details("Anas","MSIT","Computer Science Engineering");
	}
	@Bean("Object[4]")
	public Details getInstance4(){
		return new Details("Shahbaz","GB Pant","Computer Science Engineering");
	}
	@Bean("Object[5]")
	public Details getInstance5(){
		return new Details("Irfan","GNIOT","Computer Science Engineering");
	}
	@Bean("Object[6]")
	public Details getInstance6(){
		return new Details("Talha","BPIT","Computer Science Engineering");
	}
}
