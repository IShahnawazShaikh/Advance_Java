package beans;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
@Component("student")
public class Student{
	private Optional<Details> detail;
	private Email email;
	Student(){
		System.out.println("Student default Constructor");
	}
	@Autowired  //You can remove Optional by making Autowired(required=true)
	public void setterMethod(Optional<Details> detail){
		System.out.println("Setter Method");
		this.detail=detail;
		System.out.println(detail);  //If Config doesn't create Object it will print 'Optiona.Empty'
		System.out.println("****************************************************");
	}
	@Autowired
	public void setterMethodNullable(@Nullable Email email){
		System.out.println("Setter Method Nullable");
		this.email=email;
		System.out.println(email);     //If Config doesn't create Object it will print 'Null'
		System.out.println("****************************************************");
	
	}

}
