package Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import beans.Details;
import beans.Email;
@Configuration
@ComponentScan("beans")
public class Config {
//	@Bean("Object[1]")
//	public Details getInstance1(){
//		return new Details("shahnawaz","HMR-ITM","Computer Science Engineering");
//	}
//	@Bean("Object[2]")
//	public Email getInstance2(){
//		return new Email();
//	}
}
