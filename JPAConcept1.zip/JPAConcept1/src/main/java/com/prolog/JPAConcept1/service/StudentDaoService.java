package com.prolog.JPAConcept1.service;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.prolog.JPAConcept1.pojo.Student;
@Repository
@Transactional
public class StudentDaoService {
    @PersistenceContext
    EntityManager entityManager;
	public long insert(Student student) {
		entityManager.persist(student);	
		return student.getId();
	}
	public long update(Student student) {
		entityManager.merge(student);
		return student.getId();
	}
	public Student findById(long id) {
		return entityManager.find(Student.class, id);
	}
	public List<Student> findAll() {
	  TypedQuery<Student> query= entityManager.createNamedQuery("find_all_user",Student.class);
		return query.getResultList();
	}
	public void deleteById(long id) {
		entityManager.remove(findById(id));
	}
	
     
}
