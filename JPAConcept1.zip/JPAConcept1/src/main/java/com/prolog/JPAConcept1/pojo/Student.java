package com.prolog.JPAConcept1.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
@Entity
@NamedQuery(name="find_all_user",query="SELECT U FROM Student U")
public class Student {
	@Id
	@GeneratedValue
	private long id;
    private String name;
    private String course;
	public Student() {}
	public Student(String name, String course) {
		super();
		this.name = name;
		this.course = course;
	}
	public Student(long id, String name, String course) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}    
	@Override
	public String toString() {
		return "[id=" + id + ", name=" + name + ", course=" + course + "]";
	}


}
