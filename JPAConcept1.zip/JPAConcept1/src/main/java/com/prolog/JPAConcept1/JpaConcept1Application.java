package com.prolog.JPAConcept1;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.prolog.JPAConcept1.pojo.Student;
import com.prolog.JPAConcept1.service.StudentDaoService;
@SpringBootApplication
public class JpaConcept1Application implements CommandLineRunner{
   Logger log=LoggerFactory.getLogger(JpaConcept1Application.class);
   @Autowired
   StudentDaoService  studentdaoservice;
	public static void main(String[] args) {
		SpringApplication.run(JpaConcept1Application.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
	     log.info("Student inserted with ID: "+studentdaoservice.insert(new Student("Shahnawaz","CSE")));
	     log.info("Student inserted with ID: "+studentdaoservice.insert(new Student("Arif","CSE")));
	     
	     log.info("Student inserted with ID: "+studentdaoservice.update(new Student(100L,"Saquib","CSE")));  //100 but in DB=>3
	     studentdaoservice.update(new Student(2L,"Pasha","CSE"));
	     studentdaoservice.update(new Student(100L,"Irfan","CSE"));
	     
	     long myid=1L;
	      log.info("\nStudent Details with ID {} are {}",myid,studentdaoservice.findById(myid)); 
	      log.info("\nAll users are {}: ",studentdaoservice.findAll());
	      studentdaoservice.deleteById(1L);
	      log.info("\nAll users are {}: ",studentdaoservice.findAll());    
	}
}
