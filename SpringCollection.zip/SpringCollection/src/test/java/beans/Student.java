package beans;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

public class Student {
	@Autowired()
	private List<Course> list;
	@Autowired
	private Set<Student> set;
	@Autowired
	private Map<String,Course> map;
   public Student(){
	   System.out.println("Student Default Constructor");
   }
public void display() {
	System.out.println(list);
	System.out.println(set);
	System.out.println(map);
}
   
}
