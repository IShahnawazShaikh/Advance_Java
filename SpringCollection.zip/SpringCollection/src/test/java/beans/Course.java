package beans;
public class Course {
	public Course(){
		System.out.println("Course Default Constructor");
	}
}
