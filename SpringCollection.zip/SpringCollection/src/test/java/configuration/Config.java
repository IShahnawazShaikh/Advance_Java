package configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import beans.Course;
import beans.Student;

@ComponentScan("beans")
public class Config {
	@Bean("student1")
	public Student getStudentInstance(){
		return new Student();
	}
	@Bean("course1")
	public Course getInstance1(){		
		return new Course();
	}
	@Bean("course2")
	public Course getInstance2(){
		
		return new Course();
	}
	@Bean("student2")
	public Student getInstance3(){
		return new Student();
	}
	@Bean("student3")
	public Student getInstance4(){
		return new Student();
	}

}
