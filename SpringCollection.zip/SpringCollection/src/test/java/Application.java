import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import beans.Student;
import configuration.Config;

public class Application {
	public static void main(String...x){
		ApplicationContext context=new AnnotationConfigApplicationContext(Config.class);
		Student student1=context.getBean("student1",Student.class);
		student1.display();
		
	}

}
