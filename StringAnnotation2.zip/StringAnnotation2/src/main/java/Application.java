import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import beans.University;
import config.Config;
public class Application {
   public static void main(String...x){
	   ApplicationContext context=new AnnotationConfigApplicationContext(Config.class); 
	   University university=context.getBean("university",University.class);
	   university.display();
   }
}
