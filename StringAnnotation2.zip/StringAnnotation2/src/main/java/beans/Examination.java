package beans;

import org.springframework.stereotype.Component;

@Component
public class Examination {
	Examination(){
		System.out.println("Examination default Constructor invoked by Autowiring-Field Injection");
		
	}
}
