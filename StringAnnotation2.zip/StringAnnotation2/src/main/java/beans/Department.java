package beans;

import org.springframework.stereotype.Component;

@Component
public class Department {
	Department(){
		System.out.println("Department default Constructor invoked by Autowiring-Constructor Injection");
		
	}
}
