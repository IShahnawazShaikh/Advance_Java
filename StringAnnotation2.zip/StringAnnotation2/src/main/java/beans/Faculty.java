package beans;

import org.springframework.stereotype.Component;

@Component
public class Faculty {
	Faculty(){
		System.out.println("Faculty default Constructor invoked by Autowiring-Setter Injection");
		
	}
}
