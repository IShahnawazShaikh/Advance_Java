package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("university")
public class University {
	Department department;
	Faculty faculty;
	@Autowired
	Examination examination;
	@Autowired
	University(Department department){
		System.out.println("University default Constructor");
		this.department=department;
	}
	@Autowired
	public void FacultySetterMethod(Faculty faculty){
		 this.faculty=faculty;
	}
	public void display(){
		System.out.println("University bean: "+this);
		System.out.println("*********************************");
		System.out.println("Department bean: "+department);
		System.out.println("*********************************");
		System.out.println("Faculty bean: "+faculty);
		System.out.println("*********************************");
		System.out.println("Examination bean: "+examination);
		System.out.println("*********************************");
		
		
	}
}
