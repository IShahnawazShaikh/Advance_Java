package com.prolog.SpringJdbc1;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import beans.Person;
public class CustomRowMapper implements RowMapper<Person> {

	@Override
	public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
	     Person person=new Person();
	     person.setId(rs.getInt("ID"));
	     person.setName(rs.getString("NAME"));
	     person.setAddress(rs.getString(3));
	    person.setDateOfBirth(rs.getTimestamp(4));
	     return person;
	}

}
