package com.prolog;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class HomeController {
	@RequestMapping("/")
	public String showpage() {
		return "home";
	}
	@RequestMapping("/registration")
	public String showForm(Model model) {
		Student student=new Student();
		model.addAttribute("student", student);
		return "form";
	}
	@RequestMapping("/processForm")
	public String showDetail(@ModelAttribute("student") Student student) {
		return "showdetail";
	}

}
