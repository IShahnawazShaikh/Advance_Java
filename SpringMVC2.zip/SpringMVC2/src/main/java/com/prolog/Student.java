package com.prolog;

import java.util.LinkedHashMap;

public class Student {
	private String firstName;
	private String lastName;
	private String course;
	private String gender;
	private String [] applycourse;
	private LinkedHashMap<String, String> cources;
	private LinkedHashMap<String, String> applycources;
	public Student() {
		cources = new LinkedHashMap<String, String>();
		applycources = new LinkedHashMap<String, String>();
		applycources.put("C","C");
		applycources.put("Cpp","Cpp");
		applycources.put("Java","Java");
		applycources.put("WB","Webdevelopment");
		applycources.put("DS","Data Structure and Algorithm");
		applycources.put("spr","Spring");
		applycources.put("react","React.js and React Native");
		applycources.put("crux","Java Crux");
		cources.put("diploma", "Diploma Engineering");
		cources.put("Bachelor of Technology ", "B.tech");
		cources.put("Master Of Technology", "M.tech");
		cources.put("Phd", "Phd");
		
		
	}
	public LinkedHashMap<String, String> getCources() { 
		return cources;
	} 
	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String [] getApplycourse() {
		return applycourse;
	}
	public void setApplycourse(String [] applycourse) {
		this.applycourse = applycourse;
	}
	public LinkedHashMap<String, String> getApplycources() {
		return applycources;
	}

}

