package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Student {
	@Autowired
	@Qualifier("instance1")
	private Email email;
	public Student(){
		System.out.println("Student Default Constructor");
	}
	public void diplay() {
		System.out.println(email);		
	}
	

}
