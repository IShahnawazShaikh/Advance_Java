package beans;

public class Email {
  public Email(){
	 System.out.println("Email Default Constructor= "+this);  
  }
}
