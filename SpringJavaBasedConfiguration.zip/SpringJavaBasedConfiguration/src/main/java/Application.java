import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import Configuration.Config;
import beans.Email;
import beans.Student;
public class Application {
	public static void main(String...x){
	ApplicationContext context=new AnnotationConfigApplicationContext(Config.class);
	System.out.println("Getting Beans"); //executed at last of bean constructor because scope is singleton
	Student student1=context.getBean("student1",Student.class);
   System.out.println("Getting second Bean");
	Email instance2=context.getBean("instance2",Email.class);
	student1.diplay();
	}
	
}
