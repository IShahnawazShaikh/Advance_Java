package Configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import beans.Email;
import beans.Student;

@Configuration
@ComponentScan("beans")
public class Config {
	@Bean("student1")
	public Student getInstance(){
		return new Student();
	}
	@Bean("instance1")
	@Scope("singleton")
	public Email getInstanceOfEmail1(){
		return new Email();
	}
	@Bean("instance2")
	@Scope("prototype")
	public Email getInstanceOfEmail2(){
		return new Email();
	}

}
