package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("student")
public class Student {
	static int totalStudent=0;
	String name;
	Course course;
	@Autowired
	Student(Course course){
	 System.out.println("Student Parameterized constructor");
	 this.course=course;
  }
	public void register(String name) {
		totalStudent++;
		this.name=name;
	}
	public void display(){
		System.out.println("Name: "+name);
		course.courseDetails();
	}
	
}
