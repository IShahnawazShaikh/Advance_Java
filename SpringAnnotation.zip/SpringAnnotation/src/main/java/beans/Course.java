package beans;

import org.springframework.stereotype.Component;

@Component
public class Course {
	Course(){
		System.out.println("Course default Constructor");
	}
	public void courseDetails() {
		System.out.println("Course :B.tech in Computer Science Engineering");
		System.out.println("Year :2nd Year");
		
	}

	

}
