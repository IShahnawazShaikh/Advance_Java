package com.prolog;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam; 

@Controller 
public class HomeController {
		@RequestMapping("/")
		public String showpage(){
			return "home"; 
		}
		@RequestMapping("/enquiry")
		public String enroll(){
			return "enquiry"; 
		} 
		@RequestMapping("/process")
		public String detail(){
			return "detail"; 
		}
		@RequestMapping("/processModel")
		public String viewModal(HttpServletRequest request,Model modal){
			modal.addAttribute("name", request.getParameter("name").toUpperCase());

			modal.addAttribute("message", request.getParameter("message").toUpperCase());
			return "detailModal"; 
		} 
		@RequestMapping("/processModelParam")
		public String viewModalParam(@RequestParam(name="name") String name,@RequestParam(name="message") String message,Model modal){
			modal.addAttribute("name",name.toUpperCase());
			modal.addAttribute("message",message.toUpperCase());
			return "detailRequestModal"; 
		}
		}
