import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import Configuration.Config;
import beans.Student;

public class Application {
	public static void main(String...x){
		ApplicationContext context=new AnnotationConfigApplicationContext(Config.class);
		Student student1=context.getBean("Student1",Student.class);
		student1.display();
	}
}
