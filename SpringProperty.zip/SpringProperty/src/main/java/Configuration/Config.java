package Configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import beans.Student;

@Configuration
@ComponentScan("beans")
@PropertySource("Db.properties")
public class Config {
	@Value("${User_name}")
	private String username;
	
	@Value("${password}")
	private String password;
	@Bean("Student1")
	public Student getInstance(){
		return new Student(username,password);
	}
}
