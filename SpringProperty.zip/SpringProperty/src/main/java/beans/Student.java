package beans;

public class Student {
   String username;
   String passowrd;
	public Student(String username,String password){
		System.out.println("Student parameterized Constructor");
		this.username=username;
		this.passowrd=password;
	}
	public void display(){
		System.out.println("In Display Method");
		System.out.println("Username= "+username);
		System.out.println("Password=" +passowrd);
		
		
	}
}
